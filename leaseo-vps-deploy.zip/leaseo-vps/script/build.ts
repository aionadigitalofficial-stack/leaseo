import * as esbuild from "esbuild";
import { execSync } from "child_process";

async function build() {
  console.log("Building frontend with Vite...");
  execSync("npx vite build", { stdio: "inherit" });
  
  console.log("Building backend with esbuild...");
  await esbuild.build({
    entryPoints: ["server/index.ts"],
    bundle: true,
    platform: "node",
    target: "node18",
    outfile: "dist/index.cjs",
    format: "cjs",
    external: [
      "pg-native",
      "bufferutil",
      "utf-8-validate",
    ],
    sourcemap: true,
    minify: false,
  });
  
  console.log("Build completed successfully!");
}

build().catch((err) => {
  console.error("Build failed:", err);
  process.exit(1);
});
