# Leaseo VPS Deployment Guide

## Prerequisites
- Node.js 18+ and npm
- PostgreSQL 15+ database
- Linux VPS (Ubuntu 20.04+ recommended)

## Quick Start

### 1. Upload Files
Upload all files from this package to your VPS, e.g., `/var/www/leaseo`

### 2. Configure Environment
```bash
cd /var/www/leaseo
cp .env.example .env
nano .env  # Edit with your values
```

### 3. Install Dependencies
```bash
npm i
```

### 4. Setup Database
```bash
# Create PostgreSQL database
createdb leaseo

# Import the database dump
psql leaseo < database_dump.sql

# Or use Drizzle to create fresh tables
npm run db:push
```

### 5. Build for Production
```bash
npm run build
```

### 6. Start Application
```bash
npm start
```

### 7. Use PM2 for Process Management (Recommended)
```bash
npm i -g pm2
pm2 start npm --name "leaseo" -- start
pm2 save
pm2 startup
```

## Nginx Configuration
```nginx
server {
    listen 80;
    server_name leaseo.in www.leaseo.in;
    
    # Serve uploaded files
    location /uploads/ {
        alias /var/www/leaseo/uploads/;
        expires 30d;
        add_header Cache-Control "public, immutable";
    }
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## SSL with Certbot
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d leaseo.in -d www.leaseo.in
```

## Default Admin Credentials
- Email: admin@leaseo.in
- Password: Admin@123

**Important: Change the admin password after first login!**

## File Uploads
Files are stored in the `/uploads` directory:
- `/uploads/public/` - Public images
- `/uploads/private/` - Private files

Ensure the uploads directory is writable:
```bash
mkdir -p uploads/public uploads/private
chmod -R 755 uploads
```

## Environment Variables
See `.env.example` for all available configuration options.

## Troubleshooting

### Database Connection
If you get connection errors, check:
- PostgreSQL is running: `sudo systemctl status postgresql`
- DATABASE_URL is correct in `.env`
- User has proper permissions

### Permission Errors
```bash
chown -R www-data:www-data /var/www/leaseo
chmod -R 755 /var/www/leaseo
```

### View Logs
```bash
pm2 logs leaseo
```

## Updates
To update the application:
1. Upload new files
2. Run `npm i` (if dependencies changed)
3. Run `npm run build`
4. Run `pm2 restart leaseo`
