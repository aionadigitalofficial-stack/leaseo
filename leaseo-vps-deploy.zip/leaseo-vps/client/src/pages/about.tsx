import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { TrustSection } from "@/components/trust-section";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import { ArrowRight, Target, Eye, Heart } from "lucide-react";
import { EditableText } from "@/components/editable-text";
import { EditableImage } from "@/components/editable-image";
import { SEOHead } from "@/components/seo-head";
import type { PageContent } from "@shared/schema";

const values = [
  {
    icon: Target,
    title: "Our Mission",
    description: "To simplify the rental process by connecting tenants directly with property owners, eliminating unnecessary fees and creating transparent, trustworthy relationships.",
  },
  {
    icon: Eye,
    title: "Our Vision",
    description: "A world where finding a rental home is as simple as finding a friend, where trust and transparency are the foundation of every transaction.",
  },
  {
    icon: Heart,
    title: "Our Values",
    description: "Integrity, transparency, and user-first thinking guide everything we do. We believe in fair pricing, honest communication, and building lasting relationships.",
  },
];

const DEFAULT_ABOUT_CONTENT = {
  heroTitle: "About Leaseo",
  heroSubtitle: "We're on a mission to transform the rental experience by connecting renters directly with property owners. No middlemen, no hidden fees, just simple and transparent renting.",
  heroImage: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=1920&auto=format&fit=crop",
  storyTitle: "Our Story",
  storyParagraph1: "Leaseo was born from a simple frustration: why does renting have to be so complicated and expensive? As renters ourselves, we experienced firsthand the hidden fees, poor communication, and lack of transparency that plagues the rental industry.",
  storyParagraph2: "Founded in 2020, we set out to build something different. A platform where landlords and tenants could connect directly, where every listing is verified, and where trust is earned through transparency.",
  storyParagraph3: "Today, we've helped thousands of people find their perfect rental home, and we're just getting started. Our goal is to make renting as simple and stress-free as it should be.",
  storyImage: "https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=800&auto=format&fit=crop",
};

export default function AboutPage() {
  const { data: pageData } = useQuery<PageContent>({
    queryKey: ["/api/pages/about"],
  });

  const content = pageData?.content as Record<string, string> | undefined;
  
  const [localContent, setLocalContent] = useState(DEFAULT_ABOUT_CONTENT);

  useEffect(() => {
    if (content) {
      setLocalContent({
        heroTitle: content.heroTitle || DEFAULT_ABOUT_CONTENT.heroTitle,
        heroSubtitle: content.heroSubtitle || DEFAULT_ABOUT_CONTENT.heroSubtitle,
        heroImage: content.heroImage || DEFAULT_ABOUT_CONTENT.heroImage,
        storyTitle: content.storyTitle || DEFAULT_ABOUT_CONTENT.storyTitle,
        storyParagraph1: content.storyParagraph1 || DEFAULT_ABOUT_CONTENT.storyParagraph1,
        storyParagraph2: content.storyParagraph2 || DEFAULT_ABOUT_CONTENT.storyParagraph2,
        storyParagraph3: content.storyParagraph3 || DEFAULT_ABOUT_CONTENT.storyParagraph3,
        storyImage: content.storyImage || DEFAULT_ABOUT_CONTENT.storyImage,
      });
    }
  }, [content]);

  const updateContent = (key: keyof typeof localContent) => (value: string) => {
    setLocalContent((prev) => ({ ...prev, [key]: value }));
  };

  return (
    <div className="min-h-screen flex flex-col">
      <SEOHead
        title={pageData?.metaTitle || "About Leaseo - Zero Brokerage Property Platform"}
        description={pageData?.metaDescription || "Learn about Leaseo, India's leading zero brokerage property rental platform. Connect directly with property owners."}
        keywords={(pageData as any)?.metaKeywords || ["about leaseo", "zero brokerage", "property platform", "rental platform india"]}
      />
      <Header />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative py-20 md:py-32 overflow-hidden">
          <div 
            className="absolute inset-0 bg-cover bg-center"
            style={{
              backgroundImage: `url('${localContent.heroImage}')`,
            }}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-black/80 to-black/60" />
          </div>
          
          <div className="relative container mx-auto px-4">
            <div className="max-w-2xl">
              <EditableText
                value={localContent.heroTitle}
                onChange={updateContent("heroTitle")}
                as="h1"
                className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6"
                contentKey="about.heroTitle"
              />
              <EditableText
                value={localContent.heroSubtitle}
                onChange={updateContent("heroSubtitle")}
                as="p"
                className="text-lg md:text-xl text-white/90 mb-8"
                contentKey="about.heroSubtitle"
              />
              <Link href="/properties">
                <Button size="lg" className="gap-2" data-testid="button-explore-properties">
                  Explore Properties
                  <ArrowRight className="h-5 w-5" />
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Our Story */}
        <section className="py-16 md:py-24">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <EditableText
                  value={localContent.storyTitle}
                  onChange={updateContent("storyTitle")}
                  as="h2"
                  className="text-3xl md:text-4xl font-bold mb-6"
                  contentKey="about.storyTitle"
                />
                <div className="space-y-4 text-muted-foreground">
                  <EditableText
                    value={localContent.storyParagraph1}
                    onChange={updateContent("storyParagraph1")}
                    as="p"
                    contentKey="about.storyParagraph1"
                  />
                  <EditableText
                    value={localContent.storyParagraph2}
                    onChange={updateContent("storyParagraph2")}
                    as="p"
                    contentKey="about.storyParagraph2"
                  />
                  <EditableText
                    value={localContent.storyParagraph3}
                    onChange={updateContent("storyParagraph3")}
                    as="p"
                    contentKey="about.storyParagraph3"
                  />
                </div>
              </div>
              <div className="relative">
                <EditableImage
                  src={localContent.storyImage}
                  alt="Our team working together"
                  onChange={updateContent("storyImage")}
                  className="rounded-lg shadow-lg w-full h-auto"
                  contentKey="about.storyImage"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Mission, Vision, Values */}
        <section className="py-16 md:py-24 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">What Drives Us</h2>
              <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
                Our mission, vision, and values guide every decision we make.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {values.map((item) => (
                <Card key={item.title}>
                  <CardContent className="p-6">
                    <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                      <item.icon className="h-7 w-7 text-primary" />
                    </div>
                    <h3 className="text-xl font-semibold mb-3">{item.title}</h3>
                    <p className="text-muted-foreground">{item.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Trust Section */}
        <TrustSection />

        {/* CTA Section */}
        <section className="py-16 md:py-24 bg-primary">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-primary-foreground mb-4">
              Ready to Find Your Perfect Home?
            </h2>
            <p className="text-primary-foreground/90 text-lg mb-8 max-w-2xl mx-auto">
              Join our community of satisfied renters and landlords today.
            </p>
            <Link href="/properties">
              <Button size="lg" variant="secondary" className="gap-2" data-testid="button-browse-rentals">
                Browse Rentals
                <ArrowRight className="h-5 w-5" />
              </Button>
            </Link>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
